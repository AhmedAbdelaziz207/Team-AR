enum UserRole {
  User,
  Admin
}