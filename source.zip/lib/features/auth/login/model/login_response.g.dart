// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'login_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LoginResponse _$LoginResponseFromJson(Map<String, dynamic> json) =>
    LoginResponse(
      token: json['token'] as String?,
      userName: json['userName'] as String?,
      role: json['role'] as String?,
      id: json['id'] as String?,
      isPaid: json['isPaid'] as bool?,
      isDataCompleted: json['dataCompleted'] as bool?,
    );

Map<String, dynamic> _$LoginResponseToJson(LoginResponse instance) =>
    <String, dynamic>{
      'token': instance.token,
      'userName': instance.userName,
      'role': instance.role,
      'id': instance.id,
      'isPaid': instance.isPaid,
      'dataCompleted': instance.isDataCompleted,
    };
