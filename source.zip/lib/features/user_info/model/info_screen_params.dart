import '../../home/admin/data/trainee_model.dart';

class InfoScreenParams {
  final String? exerciseId;
  final TraineeModel user ;

  InfoScreenParams({this.exerciseId, required this.user});
}