class RegisterSuccessModel {
  final String? email;

  final String? password;

  final String? userName;

  RegisterSuccessModel({
    this.email,
    this.password,
    this.userName,
  });
}
