class WorkoutModel{

  final String title;
  final String image1;
  final String image2;

  WorkoutModel({required this.title,required this.image1,required this.image2});

  

}