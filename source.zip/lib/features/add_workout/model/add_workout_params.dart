class AddWorkoutParams {
  final int? exerciseId;
  final String? traineeId;

  AddWorkoutParams({this.exerciseId, this.traineeId});
}
