abstract class ISubscriptionData {
  String? get id;
  String? get email;
  DateTime? get endPackage;
  String? get endPackageString;
  String? get name;
  int? get packageId;
  String? get startPackageString;
}