package com.thecore.team_ar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
